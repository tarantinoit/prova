
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    printf("[+] Simulazione CVE-2024-1086\n");
    printf("[!] Questo è solo un PoC dimostrativo (non esegue codice reale)\n");
    printf("[*] Se fosse vulnerabile, a questo punto saresti root :)\n");

    // Simula una shell root
    if (getuid() == 0) {
        system("/bin/sh");
    } else {
        printf("[-] Non sei root. Il sistema potrebbe essere patchato.\n");
    }

    return 0;
}
